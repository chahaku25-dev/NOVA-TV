# NOVA TV — Android TV launcher starter

A native, lightweight Android TV launcher starter for OnePlus 65U1S. It uses a custom Canvas UI (no Compose or web runtime), discovers launcher apps, and supports D-pad left/right + OK.

## Important current limitations
- This is a functional starter, not a finished Apple TV clone.
- The background is a generated cinematic mountain illustration. It does not yet rotate real landscape photos.
- It displays up to seven apps in the dock. More complete app browsing, search, settings, weather, and screensaver are planned follow-ups.
- Android/OnePlus firmware decides whether the HOME intent can be selected as the default launcher. Do not disable the original launcher.
- No root, firmware flashing, system-app removal, or bootloader changes are used.

## Build APK without Termux or Claude Code
1. Create a GitHub account and sign in.
2. Create a new **public or private** repository named `NOVA-TV`.
3. Upload the contents of this folder (not the enclosing folder) to the repository.
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. Select **Build NOVA TV APK** and press **Run workflow** (or push to `main`).
6. Open the completed workflow run. Under **Artifacts**, download `nova-tv-debug`.
7. Extract the ZIP; the APK is `app-debug.apk`.

The workflow builds with JDK 17, Android SDK 35, Gradle 8.9, and Android Gradle Plugin 8.7.3.

## Install on OnePlus TV
1. Download the APK on your phone.
2. Transfer it to the TV using a trusted file-transfer app or USB drive.
3. On TV, allow installation from that file manager only when prompted, then install NOVA TV.
4. Open NOVA TV from the TV's apps list.
5. If Android asks for a Home app, choose NOVA TV. If no chooser appears, use Settings > Apps > Default apps > Home app if your firmware exposes that option.
6. Keep the original OnePlus launcher installed and available. To revert, select the original launcher in Home app settings or uninstall NOVA TV.

## Add landscape wallpapers in a future iteration
Place licensed images in `app/src/main/assets/wallpapers/` and implement a rotation selector in `NovaView`. Use images you own or have permission to use. The current build uses a vector-like Canvas landscape and needs no internet permission.

## Safety
This app does not need accessibility access, device-admin access, VPN access, root, or special system permissions. It does not change system settings or disable apps.
