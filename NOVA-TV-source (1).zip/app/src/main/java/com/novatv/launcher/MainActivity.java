package com.novatv.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private NovaView novaView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        novaView = new NovaView();
        setContentView(novaView);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && novaView != null) novaView.invalidate();
    }

    private class AppItem {
        String label, pkg;
        Drawable icon;
        AppItem(String l, String p, Drawable d) { label=l; pkg=p; icon=d; }
    }

    private class NovaView extends View {
        Paint p = new Paint(3);
        ArrayList<AppItem> apps = new ArrayList<>();
        int selected = 0;
        long lastRefresh = 0;
        float density;
        int silver = Color.rgb(222,225,230);
        int muted = Color.rgb(157,164,175);
        int white = Color.WHITE;
        int black = Color.rgb(4,5,8);

        NovaView() {
            super(MainActivity.this);
            density = getResources().getDisplayMetrics().density;
            setFocusable(true);
            setFocusableInTouchMode(true);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            loadApps();
        }

        float s(float v) { return v * density; }

        void loadApps() {
            apps.clear();
            PackageManager pm = getPackageManager();
            Intent lean = new Intent(Intent.ACTION_MAIN);
            lean.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(lean, 0);
            if (list == null || list.isEmpty()) {
                Intent normal = new Intent(Intent.ACTION_MAIN);
                normal.addCategory(Intent.CATEGORY_LAUNCHER);
                list = pm.queryIntentActivities(normal, 0);
            }
            if (list != null) {
                for (ResolveInfo ri : list) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    String label = ri.loadLabel(pm).toString();
                    boolean duplicate = false;
                    for (AppItem a : apps) if (a.pkg.equals(pkg)) duplicate = true;
                    if (!duplicate) apps.add(new AppItem(label, pkg, ri.loadIcon(pm)));
                }
            }
            apps.sort((a,b) -> a.label.compareToIgnoreCase(b.label));
            if (apps.isEmpty()) apps.add(new AppItem("No apps found", "", null));
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            // OLED black base and cinematic dusk sky
            p.setShader(new android.graphics.LinearGradient(0,0,0,h,
                    new int[]{Color.rgb(7,10,17),Color.rgb(14,19,29),Color.rgb(3,4,7)},
                    null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);

            // subtle cinematic horizon, layered mountain silhouettes
            float horizon=h*0.57f;
            p.setShader(new android.graphics.LinearGradient(0,horizon- s(180),0,horizon+s(100),
                    new int[]{Color.argb(0,110,132,160),Color.argb(65,70,88,112),Color.argb(0,0,0,0)},
                    null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0,horizon-s(180),w,horizon+s(100),p); p.setShader(null);
            Path back=new Path();
            back.moveTo(0,horizon+s(20)); back.lineTo(w*.18f,horizon-s(115));
            back.lineTo(w*.34f,horizon-s(35)); back.lineTo(w*.53f,horizon-s(155));
            back.lineTo(w*.72f,horizon-s(30)); back.lineTo(w*.88f,horizon-s(110));
            back.lineTo(w,horizon-s(15)); back.lineTo(w,h); back.lineTo(0,h); back.close();
            p.setColor(Color.rgb(19,27,39)); c.drawPath(back,p);
            Path front=new Path();
            front.moveTo(0,horizon+s(65)); front.lineTo(w*.2f,horizon-s(5));
            front.lineTo(w*.42f,horizon+s(38)); front.lineTo(w*.65f,horizon-s(32));
            front.lineTo(w*.82f,horizon+s(30)); front.lineTo(w,horizon-s(5));
            front.lineTo(w,h); front.lineTo(0,h); front.close();
            p.setColor(Color.rgb(8,12,19)); c.drawPath(front,p);

            // top bar
            p.setColor(silver); p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); p.setTextSize(s(18));
            c.drawText("N O V A", s(48), s(55), p);
            p.setColor(muted); p.setTextSize(s(12)); p.setTypeface(Typeface.create("sans-serif",0));
            String date = new SimpleDateFormat("EEE, d MMM  •  h:mm a", Locale.getDefault()).format(new Date());
            float tw=p.measureText(date); c.drawText(date,w-s(48)-tw,s(53),p);

            // hero title
            p.setColor(white); p.setTypeface(Typeface.create("sans-serif-light",0)); p.setTextSize(s(42));
            c.drawText("Your space.",s(54),h*.39f,p);
            p.setColor(silver); p.setTextSize(s(15)); p.setTypeface(Typeface.create("sans-serif",0));
            c.drawText("Everything you love, in one place.",s(57),h*.39f+s(30),p);

            // dock cards
            float cardW=Math.min(s(118), (w-s(100))/Math.max(1,Math.min(apps.size(),7)));
            float cardH=s(88), gap=s(14);
            int visible=Math.min(apps.size(),7);
            float total=visible*cardW+(visible-1)*gap;
            float start=(w-total)/2f;
            float top=h-s(142);
            for(int i=0;i<visible;i++) {
                AppItem a=apps.get(i);
                float x=start+i*(cardW+gap);
                boolean focus=(i==selected);
                RectF r=new RectF(x,top-(focus?s(8):0),x+cardW,top+cardH-(focus?s(8):0));
                p.setColor(focus?Color.rgb(49,54,64):Color.argb(185,24,28,36));
                c.drawRoundRect(r,s(17),s(17),p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(focus?s(2):s(1));
                p.setColor(focus?silver:Color.argb(80,210,216,226));
                c.drawRoundRect(r,s(17),s(17),p); p.setStyle(Paint.Style.FILL);
                if(a.icon!=null) {
                    int pad=(int)s(22);
                    a.icon.setBounds((int)(x+cardW/2-pad/2),(int)(r.top+s(10)),
                            (int)(x+cardW/2+pad/2),(int)(r.top+s(10)+pad));
                    a.icon.draw(c);
                }
                p.setColor(focus?white:muted); p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(s(11)); p.setTypeface(Typeface.create("sans-serif-medium",0));
                String label=a.label.length()>16?a.label.substring(0,15)+"…":a.label;
                c.drawText(label,x+cardW/2,r.bottom-s(13),p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            p.setColor(Color.argb(120,190,198,210)); p.setTextSize(s(10));
            p.setTypeface(Typeface.create("sans-serif",0));
            c.drawText("NOVA TV  •  Use ← → to navigate  •  OK to open",s(48),h-s(24),p);
        }

        @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
            int count=Math.min(apps.size(),7);
            if (keyCode==KeyEvent.KEYCODE_DPAD_RIGHT) { selected=(selected+1)%count; invalidate(); return true; }
            if (keyCode==KeyEvent.KEYCODE_DPAD_LEFT) { selected=(selected-1+count)%count; invalidate(); return true; }
            if (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER) {
                if (!apps.isEmpty() && !apps.get(selected).pkg.isEmpty()) {
                    Intent launch=getPackageManager().getLaunchIntentForPackage(apps.get(selected).pkg);
                    if (launch!=null) try { startActivity(launch); } catch(Exception ignored) {}
                }
                return true;
            }
            if (keyCode==KeyEvent.KEYCODE_MENU) { loadApps(); invalidate(); return true; }
            return super.onKeyDown(keyCode,event);
        }
    }
}
